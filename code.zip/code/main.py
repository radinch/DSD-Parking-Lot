import random

def generate_enter_exit_flags():
    uni_car_entered_flag = random.choice([1, 0])
    uni_car_exited_flag = 1 - uni_car_entered_flag  # opposite of uni_car_entered_flag
    other_car_entered_flag = random.choice([0, 1])
    other_car_exited_flag = 1 - other_car_entered_flag  # opposite of other_car_entered_flag
    return uni_car_entered_flag, uni_car_exited_flag, other_car_entered_flag, other_car_exited_flag

def generate_car_flags():
    uni_car_flag = random.choice([1, 0])
    other_car_flag = 1 - uni_car_flag  # opposite of uni_car_flag
    no_car_flag_1 = 0
    no_car_flag_2 = 0  # opposite of no_car_flag_1
    return uni_car_flag, other_car_flag, no_car_flag_1, no_car_flag_2

def determine_display_message(uni_car_flag, uni_car_entered_flag, uni_car_exited_flag):
    if uni_car_flag and uni_car_entered_flag:
        return 'entrance of university'
    elif uni_car_flag and not uni_car_entered_flag:
        return 'entrance of free car'
    elif not uni_car_flag and uni_car_exited_flag:
        return 'exit of university car'
    else:
        return 'exit of free car'

def populate_template(template, flags):
    return template.format(
        uni_car_entered_flag=flags['uni_car_entered_flag'], uni_car_exited_flag=flags['uni_car_exited_flag'],
        other_car_entered_flag=flags['other_car_entered_flag'], other_car_exited_flag=flags['other_car_exited_flag'],
        uni_car_flag=flags['uni_car_flag'], other_car_flag=flags['other_car_flag'],
        no_car_flag_1=flags['no_car_flag_1'], no_car_flag_2=flags['no_car_flag_2'],
        display_message=flags['display_message']
    )

def main():
    template = """
    #1
    $display("{display_message}");
    is_uni_car_entered={uni_car_entered_flag};    
    is_uni_car_exited={uni_car_exited_flag}; 
    car_entered={uni_car_flag}; car_exited={other_car_flag};
    #1
    $display("time:%d uni_parked_car: %d  parked_car: %d  uni_vacated_space: %d  vacated_space: %d  uni is vacated_space: %d is_vacated_space: %d\\n",
    current_time, uni_parked_car, parked_car, uni_vacated_space, vacated_space, uni_is_vacated_space, is_vacated_space);
    is_uni_car_entered={other_car_entered_flag};
    is_uni_car_exited={other_car_exited_flag};
    car_entered={no_car_flag_1}; car_exited={no_car_flag_2};
    """

    for i in range(200):
        uni_car_entered_flag, uni_car_exited_flag, other_car_entered_flag, other_car_exited_flag = generate_enter_exit_flags()
        uni_car_flag, other_car_flag, no_car_flag_1, no_car_flag_2 = generate_car_flags()
        display_message = determine_display_message(uni_car_flag, uni_car_entered_flag, uni_car_exited_flag)

        flags = {
            'uni_car_entered_flag': uni_car_entered_flag,
            'uni_car_exited_flag': uni_car_exited_flag,
            'other_car_entered_flag': other_car_entered_flag,
            'other_car_exited_flag': other_car_exited_flag,
            'uni_car_flag': uni_car_flag,
            'other_car_flag': other_car_flag,
            'no_car_flag_1': no_car_flag_1,
            'no_car_flag_2': no_car_flag_2,
            'display_message': display_message
        }

        code_instance = populate_template(template, flags)
        print(code_instance.strip())

if __name__ == "__main__":
    main()
